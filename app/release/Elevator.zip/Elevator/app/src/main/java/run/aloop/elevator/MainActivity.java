package run.aloop.elevator;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.gridlayout.widget.GridLayout;
import androidx.preference.PreferenceManager;

import java.util.HashMap;

import Moka7.S7;
import Moka7.S7Client;


public class MainActivity extends AppCompatActivity implements DAQEvent {

    private DAQ daq;
    private DataStruct[] ds = {
      new DataStruct(S7.S7AreaDB, 1, 0)
              .add(new DataStruct.Variable("current_floor", DataStruct.Variable.Type.SHORT))
              .add(new DataStruct.Variable("target_floor", DataStruct.Variable.Type.SHORT))
    };
    private TextView txtCurrentFloor, txtTargetFloor;
    private Handler handler = new Handler();

    public MainActivity() throws Exception {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        txtCurrentFloor = findViewById(R.id.current_floor);
        txtTargetFloor = findViewById(R.id.target_floor);

        daq = new DAQ(ds, this);
        LoadConfig();
        daq.start();

        GridLayout layout = findViewById(R.id.floors);
        for (int i = 0; i < layout.getChildCount(); i++) {
            layout.getChildAt(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (v instanceof Button) {
                        int targetFloor = Integer.parseInt(((Button) v).getText().toString(), 10);
                        daq.write("target_floor", targetFloor);
                    }
                }
            });
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivityForResult(intent, 0);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        LoadConfig();
    }

    @Override
    protected void onDestroy() {
        daq.close();
        super.onDestroy();
    }

    private void LoadConfig() {
        SharedPreferences preference = PreferenceManager.getDefaultSharedPreferences(this);
        String address = preference.getString("address", "");
        String mode = preference.getString("mode", "TSAP");
        String localTSAP = preference.getString("local_TSAP", "1000");
        String remoteTSAP = preference.getString("local_TSAP", "1000");
        String rack = preference.getString("rack", "0");
        String slot = preference.getString("slot", "0");
        daq.setParams(address, mode.equals("TSAP"), parseInt(localTSAP, 16, 0x1000),
                parseInt(remoteTSAP, 16, 0x1000), parseInt(rack, 10, 0),
                parseInt(slot, 10, 0));
    }

    private int parseInt(String v, int radix, int defaultValue) {
        try {
             return Integer.parseInt(v, radix);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "配置项 " + v + " 解析错误", Toast.LENGTH_LONG).show();
        }
        return defaultValue;
    }

    @Override
    public void OnConnectFailed(final int code) {
        System.out.println("Connect failed: " + S7Client.ErrorText(code));
        handler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, "Connect to " + daq.getAddress() +  " failed: " + S7Client.ErrorText(code), Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void OnReadFailed(final int code) {
        System.out.println("Read failed: " + S7Client.ErrorText(code));
        handler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, "Read failed: "  + S7Client.ErrorText(code), Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void OnWriteFailed(final int code) {
        System.out.println("Write failed: " + S7Client.ErrorText(code));
        handler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, "Write failed: " + S7Client.ErrorText(code), Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void OnDataReceived(final HashMap<String, Object> data) {
        this.handler.post(new Runnable() {
            @Override
            public void run() {
                Integer currentFloor = (Integer) data.get("current_floor");
                if (currentFloor != null)
                    txtCurrentFloor.setText(String.valueOf(currentFloor));
                Integer targetFloor = (Integer) data.get("target_floor");
                if (targetFloor != null)
                    txtTargetFloor.setText(String.valueOf(targetFloor));
            }
        });
    }
}
